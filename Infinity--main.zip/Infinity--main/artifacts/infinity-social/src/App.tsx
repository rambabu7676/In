import { useEffect, useMemo, useRef, useState, type ChangeEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  Bell,
  Bookmark,
  Camera,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Compass,
  Edit3,
  Film,
  Heart,
  Home as HomeIcon,
  ImagePlus,
  Info,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Play,
  Plus,
  Search,
  Send,
  Settings,
  Share2,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  UserPlus,
  UserRoundCheck,
  UserRound,
  Users,
  Video,
  X,
  Zap,
} from 'lucide-react';
import { Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();

type View = 'home' | 'reels' | 'discover' | 'messages' | 'profile';
type Quality = 'अच्छा' | 'बेहतर' | 'अल्ट्रा';

type Post = {
  id: string;
  user: string;
  handle: string;
  avatar: string;
  caption: string;
  likes: number;
  comments: number;
  saves: number;
  visual: string;
  tone: string;
  duration: string;
  liked?: boolean;
  saved?: boolean;
  localVideo?: string;
};

type Profile = {
  name: string;
  handle: string;
  bio: string;
  avatar: string;
  location: string;
  followers: number;
  following: number;
};

type Conversation = {
  id: string;
  name: string;
  initials: string;
  last: string;
  time: string;
  unread: number;
  online: boolean;
};

const initialProfile: Profile = {
  name: 'रागिनी मेहरा',
  handle: '@ragini.creates',
  bio: 'छोटे शहर से बड़ी कहानियाँ। कैमरा, चाय और रोज़ का एक नया फ्रेम।',
  avatar: 'RM',
  location: 'जयपुर, भारत',
  followers: 12840,
  following: 384,
};

const initialPosts: Post[] = [
  {
    id: 'post-1',
    user: 'कबीर अरोड़ा',
    handle: '@kabir.frames',
    avatar: 'KA',
    caption: 'शहर सोता है, तब रोशनी अपनी कहानी सुनाती है।',
    likes: 2180,
    comments: 84,
    saves: 391,
    visual: 'reel-gradient-1',
    tone: 'जयपुर की रात',
    duration: '0:18',
  },
  {
    id: 'post-2',
    user: 'मीरा स्टूडियो',
    handle: '@meera.studio',
    avatar: 'MS',
    caption: 'आज का रंग: थोड़ा सा आसमान, थोड़ा सा अपना मन।',
    likes: 1462,
    comments: 46,
    saves: 209,
    visual: 'reel-gradient-2',
    tone: 'रंगों की डायरी',
    duration: '0:24',
  },
  {
    id: 'post-3',
    user: 'नमन वर्मा',
    handle: '@namanonfilm',
    avatar: 'NV',
    caption: 'जब बारिश आती है तो पुरानी गलियाँ भी नई लगती हैं।',
    likes: 894,
    comments: 31,
    saves: 102,
    visual: 'reel-gradient-3',
    tone: 'बारिश के बाद',
    duration: '0:31',
  },
  {
    id: 'post-4',
    user: 'सारा खान',
    handle: '@sara.sings',
    avatar: 'SK',
    caption: 'एक अधूरी धुन, जिसे आपकी आवाज़ पूरी कर सकती है।',
    likes: 3621,
    comments: 118,
    saves: 474,
    visual: 'reel-gradient-4',
    tone: 'ओपन माइक',
    duration: '0:42',
  },
];

const initialConversations: Conversation[] = [
  { id: 'c1', name: 'मीरा स्टूडियो', initials: 'MS', last: 'कल वाली क्लिप कमाल थी!', time: 'अभी', unread: 2, online: true },
  { id: 'c2', name: 'नमन वर्मा', initials: 'NV', last: 'शाम को शूट पक्का?', time: '18 मि', unread: 0, online: true },
  { id: 'c3', name: 'सारा खान', initials: 'SK', last: 'आपके सेव किए गाने भेजे हैं', time: 'कल', unread: 0, online: false },
  { id: 'c4', name: 'क्रिएटर सर्कल', initials: 'CC', last: 'रविवार की मीटअप लोकेशन', time: 'सोम', unread: 0, online: false },
];

function readStorage<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // A large local video may exceed the browser quota. The active session still works.
  }
}

function formatCount(value: number) {
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `${(value / 1000).toFixed(value > 10000 ? 0 : 1)}k`;
  return value.toString();
}

function isAvatarImage(value: string) {
  return value.startsWith('data:image/') || value.startsWith('blob:') || value.startsWith('http://') || value.startsWith('https://');
}

function Avatar({ initials, size = 'md', accent = false }: { initials: string; size?: 'sm' | 'md' | 'lg' | 'xl'; accent?: boolean }) {
  const sizeClass = { sm: 'h-8 w-8 text-[10px]', md: 'h-10 w-10 text-xs', lg: 'h-16 w-16 text-lg', xl: 'h-24 w-24 text-2xl' }[size];
  return (
    <div className={`${sizeClass} ${accent ? 'avatar-accent' : 'avatar-ink'} flex shrink-0 items-center justify-center rounded-full font-extrabold tracking-tight`} data-testid={`avatar-${initials}`}>
      {isAvatarImage(initials) ? <img src={initials} alt="" className="h-full w-full rounded-full object-cover" /> : initials}
    </div>
  );
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`flex items-center gap-2.5 ${compact ? '' : 'px-1'}`} data-testid="brand-logo">
      <div className="brand-mark flex h-10 w-10 items-center justify-center rounded-[14px] text-2xl font-bold">∞</div>
      {!compact && <div><div className="text-[15px] font-extrabold leading-none tracking-[-.04em]">infinity</div><div className="mt-1 font-mono-ui text-[8px] uppercase text-sidebar-foreground/55">social video</div></div>}
    </div>
  );
}

function IconButton({ label, children, onClick, active = false, className = '', testId }: { label: string; children: ReactNode; onClick?: () => void; active?: boolean; className?: string; testId: string }) {
  return (
    <button type="button" aria-label={label} title={label} onClick={onClick} data-testid={testId} className={`icon-button ${active ? 'icon-button-active' : ''} ${className}`}>
      {children}
    </button>
  );
}

function Modal({ title, eyebrow, onClose, children }: { title: string; eyebrow?: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="modal-backdrop fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-5" role="dialog" aria-modal="true">
      <div className="modal-panel pop-in relative max-h-[92dvh] w-full overflow-y-auto rounded-t-[28px] p-5 sm:max-w-lg sm:rounded-[28px] sm:p-7">
        <button type="button" onClick={onClose} aria-label="बंद करें" data-testid="button-close-modal" className="absolute right-4 top-4 rounded-full p-2 text-muted-foreground transition hover:bg-muted hover:text-foreground"><X size={18} /></button>
        {eyebrow && <div className="eyebrow mb-2">{eyebrow}</div>}
        <h2 className="hindi pr-8 text-2xl font-extrabold tracking-[-.045em]">{title}</h2>
        {children}
      </div>
    </div>
  );
}

function Sidebar({ view, profile, onNavigate, onUpload, onHelp }: { view: View; profile: Profile; onNavigate: (view: View) => void; onUpload: () => void; onHelp: () => void }) {
  const items: { id: View; label: string; icon: typeof HomeIcon }[] = [
    { id: 'home', label: 'होम', icon: HomeIcon },
    { id: 'reels', label: 'रील्स', icon: Film },
    { id: 'discover', label: 'खोजें', icon: Compass },
    { id: 'messages', label: 'संदेश', icon: MessageCircle },
    { id: 'profile', label: 'प्रोफ़ाइल', icon: UserRound },
  ];
  return (
    <>
      <aside className="desktop-sidebar fixed inset-y-0 left-0 z-20 hidden w-[238px] flex-col bg-sidebar px-5 py-6 text-sidebar-foreground md:flex">
        <Logo />
        <div className="mt-12 space-y-1.5">
          {items.map(({ id, label, icon: Icon }) => (
            <button type="button" key={id} onClick={() => onNavigate(id)} data-testid={`nav-${id}`} className={`nav-item ${view === id ? 'nav-item-active' : ''}`}>
              <Icon size={19} strokeWidth={view === id ? 2.4 : 1.8} /><span>{label}</span>{id === 'messages' && <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">2</span>}
            </button>
          ))}
        </div>
        <div className="mt-auto space-y-1.5">
          <button type="button" onClick={onHelp} data-testid="button-help" className="nav-item"><CircleHelp size={19} /><span>मदद और सुझाव</span></button>
          <div className="mt-5 flex items-center gap-3 border-t border-sidebar-foreground/10 pt-5"><Avatar initials={profile.avatar} size="sm" accent /><div className="min-w-0"><div className="truncate text-sm font-bold">{profile.name}</div><div className="truncate text-xs text-sidebar-foreground/50">{profile.handle}</div></div><MoreHorizontal size={17} className="ml-auto text-sidebar-foreground/45" /></div>
        </div>
      </aside>
      <nav className="mobile-bottom-nav fixed inset-x-3 bottom-3 z-40 flex items-center justify-around rounded-[22px] border border-white/10 bg-sidebar/95 p-2 shadow-2xl backdrop-blur-xl md:hidden">
        {items.filter(({ id }) => id === 'home' || id === 'reels' || id === 'messages').map(({ id, label, icon: Icon }) => <button type="button" key={id} onClick={() => onNavigate(id)} data-testid={`mobile-nav-${id}`} className={`mobile-nav-item ${view === id ? 'mobile-nav-active' : ''}`}><Icon size={19} /><span>{label}</span></button>)}
        <button type="button" onClick={onUpload} data-testid="mobile-nav-upload" className="mobile-nav-create"><Plus size={19} /></button>
        {items.filter(({ id }) => id === 'discover' || id === 'profile').map(({ id, label, icon: Icon }) => <button type="button" key={id} onClick={() => onNavigate(id)} data-testid={`mobile-nav-${id}`} className={`mobile-nav-item ${view === id ? 'mobile-nav-active' : ''}`}><Icon size={19} /><span>{label}</span></button>)}
      </nav>
    </>
  );
}

function Topbar({ title, subtitle, onUpload, onNotifications, onSearch }: { title: string; subtitle: string; onUpload: () => void; onNotifications: () => void; onSearch: () => void }) {
  return (
    <header className="topbar flex items-center justify-between gap-3 border-b border-border/70 px-4 py-4 sm:px-8 sm:py-5">
      <div className="min-w-0"><div className="eyebrow mb-1">∞ / {title}</div><h1 className="hindi truncate text-[22px] font-extrabold tracking-[-.045em] sm:text-[27px]">{subtitle}</h1></div>
      <div className="flex shrink-0 items-center gap-2">
        <IconButton label="खोजें" onClick={onSearch} testId="button-top-search"><Search size={18} /></IconButton>
        <IconButton label="सूचनाएँ" onClick={onNotifications} testId="button-notifications" className="relative"><Bell size={18} /><span className="notification-dot" /></IconButton>
      </div>
    </header>
  );
}

function StoryStrip({ profile, onSelect }: { profile: Profile; onSelect: (view: View) => void }) {
  const stories = [
    { initials: profile.avatar, label: 'आपकी स्टोरी', own: true },
    { initials: 'KA', label: 'कबीर', tone: 'saffron' },
    { initials: 'MS', label: 'मीरा', tone: 'teal' },
    { initials: 'NV', label: 'नमन', tone: 'plum' },
    { initials: 'SK', label: 'सारा', tone: 'rose' },
    { initials: 'AR', label: 'आरव', tone: 'gold' },
  ];
  return <div className="flex gap-5 overflow-x-auto px-4 py-5 sm:px-8 scrollbar-none">{stories.map((story, index) => <button type="button" key={story.label} onClick={() => onSelect(index === 0 ? 'profile' : 'reels')} data-testid={`story-${index}`} className="flex min-w-[52px] flex-col items-center gap-2"><div className={`story-ring ${story.own ? 'story-own' : ''} ${story.tone ?? ''}`}><Avatar initials={story.initials} size="md" accent={story.own} /></div><span className="max-w-[65px] truncate text-[11px] font-semibold text-muted-foreground">{story.label}</span></button>)}</div>;
}

function ReelArtwork({ post, large = false }: { post: Post; large?: boolean }) {
  return (
    <div className={`${post.visual} reel-grid-texture relative ${large ? 'h-full min-h-[450px]' : 'h-[250px]'} overflow-hidden`}>
      <div className="reel-orb one" /><div className="reel-orb two" />
      <div className="absolute inset-0 flex flex-col justify-between p-5 text-card">
        <div className="flex items-start justify-between"><span className="rounded-full border border-white/25 bg-black/10 px-2.5 py-1 font-mono-ui text-[9px] uppercase backdrop-blur-sm">{post.tone}</span><span className="rounded-full bg-black/20 px-2 py-1 font-mono-ui text-[10px] backdrop-blur-sm">{post.duration}</span></div>
        <div className="relative"><div className={`${large ? 'text-4xl sm:text-6xl' : 'text-3xl'} max-w-[80%] font-extrabold leading-[.95] tracking-[-.07em]`}>{post.tone}</div><div className="mt-3 flex items-center gap-2 text-[11px] font-semibold opacity-80"><Play size={12} fill="currentColor" /> अभी चलाएं</div></div>
      </div>
    </div>
  );
}

function FollowButton({ following, onClick }: { following: boolean; onClick: () => void }) {
  return <button type="button" onClick={onClick} data-testid={following ? 'button-unfollow' : 'button-follow'} className={`follow-button ${following ? 'follow-button-following' : ''}`}><span className="follow-button-icon">{following ? <UserRoundCheck size={15} /> : <UserPlus size={15} />}</span><span className="follow-button-copy"><span className="follow-button-title">{following ? 'FOLLOWING' : 'FOLLOW'}</span><span className="follow-button-subtitle">{following ? 'CONNECTED' : 'JOIN THE CIRCLE'}</span></span></button>;
}

function PostCard({ post, onLike, onSave, onShare, onRemove, onFollow, following, isOwn, admin }: { post: Post; onLike: () => void; onSave: () => void; onShare: () => void; onRemove: () => void; onFollow: () => void; following: boolean; isOwn: boolean; admin: boolean }) {
  return (
    <article className="post-card rise-in overflow-hidden rounded-[22px] border border-border/80 bg-card shadow-[0_16px_50px_hsl(245_30%_18%/0.06)]" data-testid={`card-post-${post.id}`}>
      <div className="flex items-center gap-3 px-4 py-4 sm:px-5"><Avatar initials={post.avatar} size="sm" accent /><div className="min-w-0 flex-1"><div className="text-sm font-bold">{post.user}</div><div className="text-[11px] text-muted-foreground">{post.handle} · 2 घंटे पहले</div></div>{!isOwn && <FollowButton following={following} onClick={onFollow} />}{admin && <IconButton label="पोस्ट हटाएँ" onClick={onRemove} testId={`button-remove-${post.id}`}><Trash2 size={16} /></IconButton>}<IconButton label="अधिक विकल्प" testId={`button-more-${post.id}`}><MoreHorizontal size={18} /></IconButton></div>
      <div className="relative">{post.localVideo ? <video src={post.localVideo} controls className="h-[250px] w-full bg-foreground object-cover sm:h-[340px]" /> : <ReelArtwork post={post} />}<div className="absolute bottom-3 right-3 flex items-center gap-1.5 rounded-full bg-black/25 px-2 py-1 text-[10px] font-semibold text-white backdrop-blur-md"><Video size={12} /> HD</div></div>
      <div className="px-4 py-4 sm:px-5"><div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-1"><button type="button" onClick={onLike} data-testid={`button-like-${post.id}`} className={`action-button ${post.liked ? 'action-liked' : ''}`}><Heart size={19} fill={post.liked ? 'currentColor' : 'none'} /><span>{formatCount(post.likes)}</span></button><button type="button" data-testid={`button-comment-${post.id}`} className="action-button"><MessageCircle size={19} /><span>{formatCount(post.comments)}</span></button><button type="button" onClick={onShare} data-testid={`button-share-${post.id}`} className="action-button"><Share2 size={18} /></button></div><button type="button" onClick={onSave} data-testid={`button-save-${post.id}`} className={`action-button ${post.saved ? 'action-saved' : ''}`}><Bookmark size={19} fill={post.saved ? 'currentColor' : 'none'} /></button></div><p className="hindi text-[14px] leading-6 text-foreground/85"><span className="font-bold">{post.handle}</span> {post.caption}</p></div>
    </article>
  );
}

function HomeView({ posts, profile, followingHandles, admin, onLike, onSave, onShare, onRemove, onFollow, onUpload, onNavigate }: { posts: Post[]; profile: Profile; followingHandles: string[]; admin: boolean; onLike: (id: string) => void; onSave: (id: string) => void; onShare: (post: Post) => void; onRemove: (id: string) => void; onFollow: (post: Post) => void; onUpload: () => void; onNavigate: (view: View) => void }) {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const timer = window.setTimeout(() => setLoading(false), 520); return () => window.clearTimeout(timer); }, []);
  return <div><Topbar title="मुखपृष्ठ" subtitle={`नमस्ते, ${profile.name.split(' ')[0]}`} onUpload={onUpload} onNotifications={() => undefined} onSearch={() => onNavigate('discover')} /><div className="mx-auto max-w-[1050px]"><StoryStrip profile={profile} onSelect={onNavigate} /><div className="feed-layout px-4 pb-10 sm:px-8"><main className="min-w-0"><div className="mb-5"><div className="eyebrow mb-1">आपके लिए</div><h2 className="hindi text-xl font-extrabold tracking-[-.04em]">आज की हलचल</h2></div>{loading ? <div className="space-y-5">{[1, 2].map((item) => <div key={item} className="skeleton-card h-[380px] rounded-[22px]" />)}</div> : posts.length === 0 ? <EmptyState icon={<Film size={25} />} title="फीड अभी शांत है" description="अपनी पहली रील से इस जगह को जीवंत बनाएं।" /> : <div className="space-y-5">{posts.map((post) => <PostCard key={post.id} post={post} isOwn={post.handle === profile.handle} following={followingHandles.includes(post.handle)} onFollow={() => onFollow(post)} admin={admin} onLike={() => onLike(post.id)} onSave={() => onSave(post.id)} onShare={() => onShare(post)} onRemove={() => onRemove(post.id)} />)}</div>}</main><aside className="home-aside hidden lg:block"><div className="side-note rounded-[22px] p-5"><div className="mb-5 flex items-center justify-between"><div><div className="eyebrow mb-1">आज का संकेत</div><div className="hindi text-lg font-extrabold">अपनी नज़र से दिखाएं</div></div><Sparkles size={19} className="text-primary" /></div><p className="hindi text-sm leading-6 text-muted-foreground">सबसे याद रहने वाली रील वही होती है जो सिर्फ आपकी हो।</p></div><div className="mt-4 rounded-[22px] border border-border/80 bg-card p-5"><div className="eyebrow mb-4">ट्रेंडिंग टैग</div><div className="flex flex-wrap gap-2">{['#जयपुर', '#मूडबोर्ड', '#छोटीकहानी', '#संगीत'].map((tag) => <button type="button" key={tag} onClick={() => onNavigate('discover')} data-testid={`tag-${tag.slice(1)}`} className="tag-pill">{tag}</button>)}</div></div></aside></div></div></div>;
}

function ReelsView({ posts, profile, followingHandles, quality, setQuality, onLike, onSave, onShare, onFollow, onUpload }: { posts: Post[]; profile: Profile; followingHandles: string[]; quality: Quality; setQuality: (quality: Quality) => void; onLike: (id: string) => void; onSave: (id: string) => void; onShare: (post: Post) => void; onFollow: (post: Post) => void; onUpload: () => void }) {
  const [active, setActive] = useState(0);
  const [qualityOpen, setQualityOpen] = useState(false);
  const post = posts[active % Math.max(posts.length, 1)];
  if (!post) return <div><Topbar title="रील्स" subtitle="आपके लिए कुछ नहीं" onUpload={onUpload} onNotifications={() => undefined} onSearch={() => undefined} /><EmptyState icon={<Film size={25} />} title="अभी कोई रील नहीं" description="फीड में पहली रील जोड़ें और यहां से सफर शुरू करें।" /></div>;
  return <div><Topbar title="रील्स" subtitle="एक के बाद एक" onUpload={onUpload} onNotifications={() => undefined} onSearch={() => undefined} /><div className="reels-stage mx-auto flex max-w-[1030px] flex-col gap-5 px-4 pb-10 sm:px-8 lg:flex-row"><div className="reel-player-wrap relative w-full max-w-[620px] overflow-hidden rounded-[26px] bg-foreground shadow-[0_25px_70px_hsl(245_30%_15%_/_0.2)]"><ReelArtwork post={post} large /><div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent p-5 pt-24 text-white"><div className="flex items-end justify-between gap-5"><div className="min-w-0"><div className="mb-2 flex items-center gap-2"><Avatar initials={post.avatar} size="sm" /><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><div className="text-sm font-bold">{post.user}</div>{post.handle !== profile.handle && <FollowButton following={followingHandles.includes(post.handle)} onClick={() => onFollow(post)} />}</div><div className="text-[11px] text-white/60">{post.handle}</div></div></div><p className="hindi line-clamp-2 max-w-md text-sm leading-6">{post.caption}</p></div><div className="flex shrink-0 flex-col items-center gap-3"><button type="button" onClick={() => onLike(post.id)} data-testid={`reel-like-${post.id}`} className={`reel-action ${post.liked ? 'text-primary' : ''}`}><Heart size={22} fill={post.liked ? 'currentColor' : 'none'} /><span>{formatCount(post.likes)}</span></button><button type="button" onClick={() => onSave(post.id)} data-testid={`reel-save-${post.id}`} className={`reel-action ${post.saved ? 'text-primary' : ''}`}><Bookmark size={21} fill={post.saved ? 'currentColor' : 'none'} /><span>सेव</span></button><button type="button" onClick={() => onShare(post)} data-testid={`reel-share-${post.id}`} className="reel-action"><Share2 size={20} /><span>भेजें</span></button></div></div></div><div className="absolute right-4 top-4"><button type="button" onClick={() => setQualityOpen(!qualityOpen)} data-testid="button-quality-picker" className="flex items-center gap-1.5 rounded-full bg-black/25 px-3 py-2 font-mono-ui text-[10px] text-white backdrop-blur-md"><Zap size={12} /> {quality}<ChevronDown size={12} /></button>{qualityOpen && <div className="quality-menu pop-in mt-2 overflow-hidden rounded-xl p-1">{(['अच्छा', 'बेहतर', 'अल्ट्रा'] as Quality[]).map((item) => <button type="button" key={item} onClick={() => { setQuality(item); setQualityOpen(false); }} data-testid={`quality-${item}`} className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs font-bold ${quality === item ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}>{item}{quality === item && <Check size={13} />}</button>)}</div>}</div></div><div className="reels-rail flex flex-col gap-4 lg:w-[280px]"><div className="rounded-[22px] border border-border/80 bg-card p-5"><div className="eyebrow mb-2">अगली रील</div><h2 className="hindi mb-4 text-xl font-extrabold tracking-[-.04em]">आपके स्वाद की</h2><div className="space-y-3">{posts.slice(0, 3).map((item, index) => <button type="button" key={item.id} onClick={() => setActive(index)} data-testid={`reel-queue-${item.id}`} className={`flex w-full items-center gap-3 rounded-xl p-2 text-left transition ${active === index ? 'bg-secondary' : 'hover:bg-muted'}`}><div className={`${item.visual} relative h-14 w-12 shrink-0 overflow-hidden rounded-lg`}><Play className="absolute bottom-1 right-1 text-white" size={13} fill="currentColor" /></div><div className="min-w-0"><div className="truncate text-xs font-bold">{item.tone}</div><div className="mt-1 text-[11px] text-muted-foreground">{item.user} · {item.duration}</div></div><ChevronRight size={15} className="ml-auto text-muted-foreground" /></button>)}</div></div><div className="rounded-[22px] bg-accent p-5 text-accent-foreground"><div className="mb-3 flex items-center gap-2"><Info size={16} /><div className="eyebrow text-accent-foreground/70">क्वालिटी टिप</div></div><p className="hindi text-sm font-semibold leading-6">अच्छी रोशनी और साफ़ आवाज़ रील को ज़्यादा देर तक याद रखती है।</p></div></div></div></div>;
}

function DiscoverView({ posts, onOpenReel }: { posts: Post[]; onOpenReel: () => void }) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('सब');
  const filters = ['सब', 'लोग', 'ऑडियो', 'टैग'];
  const filtered = useMemo(() => posts.filter((post) => `${post.user} ${post.handle} ${post.caption} ${post.tone}`.toLowerCase().includes(query.toLowerCase()) || filter === 'ऑडियो'), [posts, query, filter]);
  return <div><Topbar title="खोजें" subtitle="नई नज़रें, नए फ्रेम" onUpload={() => undefined} onNotifications={() => undefined} onSearch={() => document.getElementById('discover-search')?.focus()} /><div className="mx-auto max-w-[1050px] px-4 pb-12 sm:px-8"><div className="discover-search-wrap relative"><Search size={19} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" /><input id="discover-search" value={query} onChange={(event) => setQuery(event.target.value)} data-testid="input-discover-search" className="discover-search w-full rounded-2xl border border-border/80 bg-card py-4 pl-12 pr-4 text-sm outline-none transition focus:border-primary" placeholder="लोग, रील्स या टैग खोजें..." /></div><div className="mt-4 flex gap-2 overflow-x-auto scrollbar-none">{filters.map((item) => <button type="button" key={item} onClick={() => setFilter(item)} data-testid={`filter-${item}`} className={`filter-pill ${filter === item ? 'filter-active' : ''}`}>{item}</button>)}</div><div className="discover-feature mt-8 grid gap-5 overflow-hidden rounded-[25px] p-6 sm:grid-cols-[1fr_230px] sm:p-8"><div className="relative z-10"><div className="eyebrow mb-3 text-white/70">आज का डिस्कवर</div><h2 className="hindi max-w-md text-3xl font-extrabold leading-[1.05] tracking-[-.055em] text-white sm:text-4xl">जो दिखता है,<br />वो महसूस भी हो।</h2><p className="hindi mt-4 max-w-sm text-sm leading-6 text-white/72">भारत के हर कोने से आ रही छोटी, सच्ची और थोड़ी अजीब कहानियां।</p><button type="button" onClick={onOpenReel} data-testid="button-discover-reels" className="mt-6 flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-xs font-extrabold text-foreground">रील्स देखें <ChevronRight size={15} /></button></div><div className="discover-orbit hidden sm:block"><div className="orbit-ring ring-a" /><div className="orbit-ring ring-b" /><div className="orbit-core"><Sparkles size={27} /></div></div></div><div className="mt-9 flex items-end justify-between"><div><div className="eyebrow mb-1">चुनाव आपके लिए</div><h2 className="hindi text-xl font-extrabold tracking-[-.04em]">लोकप्रिय अभी</h2></div><span className="font-mono-ui text-[10px] text-muted-foreground">{filtered.length} रील्स</span></div>{filtered.length === 0 ? <div className="mt-6"><EmptyState icon={<Search size={25} />} title="कुछ नहीं मिला" description="शब्द बदलकर फिर से खोजिए।" /></div> : <div className="discover-grid mt-5">{filtered.map((post, index) => <button type="button" key={post.id} onClick={onOpenReel} data-testid={`discover-card-${post.id}`} className={`discover-tile ${post.visual} text-left ${index === 0 ? 'discover-tile-feature' : ''}`}><div className="reel-orb one" /><div className="relative z-10 flex h-full flex-col justify-between p-4 text-white"><div className="flex items-start justify-between"><span className="rounded-full bg-black/15 px-2 py-1 font-mono-ui text-[9px] backdrop-blur-sm">{post.duration}</span><Play size={18} fill="currentColor" /></div><div><div className="text-lg font-extrabold leading-tight tracking-[-.04em]">{post.tone}</div><div className="mt-1 text-[11px] text-white/75">{formatCount(post.likes)} पसंद</div></div></div></button>)}</div>}</div></div>;
}

function MessagesView() {
  const [activeId, setActiveId] = useState('c1');
  const [message, setMessage] = useState('');
  const [conversations, setConversations] = useState(initialConversations);
  const active = conversations.find((conversation) => conversation.id === activeId) ?? conversations[0];
  const sendMessage = () => {
    if (!message.trim()) return;
    setConversations((current) => current.map((conversation) => conversation.id === activeId ? { ...conversation, last: message.trim(), time: 'अभी', unread: 0 } : conversation));
    setMessage('');
  };
  return <div><Topbar title="संदेश" subtitle="अपनों से जुड़े रहें" onUpload={() => undefined} onNotifications={() => undefined} onSearch={() => undefined} /><div className="messages-layout mx-auto max-w-[1050px] overflow-hidden border-y border-border/70 bg-card sm:my-6 sm:rounded-[24px] sm:border"><div className="conversation-list border-r border-border/70"><div className="flex items-center justify-between px-5 py-5"><div><div className="eyebrow mb-1">इनबॉक्स</div><h2 className="hindi text-xl font-extrabold">संदेश</h2></div><IconButton label="नया संदेश" testId="button-new-message"><Edit3 size={17} /></IconButton></div><div className="px-4 pb-3"><div className="relative"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input data-testid="input-message-search" className="w-full rounded-xl bg-muted py-2.5 pl-9 pr-3 text-xs outline-none" placeholder="संदेश खोजें" /></div></div><div>{conversations.map((conversation) => <button type="button" key={conversation.id} onClick={() => setActiveId(conversation.id)} data-testid={`conversation-${conversation.id}`} className={`conversation-row ${activeId === conversation.id ? 'conversation-active' : ''}`}><div className="relative"><Avatar initials={conversation.initials} size="md" /><span className={`presence-dot ${conversation.online ? '' : 'presence-off'}`} /></div><div className="min-w-0 flex-1 text-left"><div className="flex items-center justify-between gap-2"><span className="truncate text-sm font-bold">{conversation.name}</span><span className="shrink-0 text-[10px] text-muted-foreground">{conversation.time}</span></div><div className="mt-1 flex items-center justify-between gap-2"><span className="truncate text-xs text-muted-foreground">{conversation.last}</span>{conversation.unread > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">{conversation.unread}</span>}</div></div></button>)}</div></div><div className="message-thread"><div className="flex items-center gap-3 border-b border-border/70 px-5 py-4 sm:px-7"><Avatar initials={active.initials} size="sm" /><div className="min-w-0"><div className="text-sm font-bold">{active.name}</div><div className="text-[11px] text-muted-foreground">{active.online ? 'अभी ऑनलाइन' : 'ऑफलाइन'}</div></div><IconButton label="अधिक विकल्प" testId="button-message-more" className="ml-auto"><MoreHorizontal size={18} /></IconButton></div><div className="thread-content"><div className="mx-auto mt-auto max-w-sm text-center"><div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground"><MessageCircle size={22} /></div><div className="hindi text-sm font-bold">{active.name} से बातचीत शुरू करें</div><p className="hindi mt-2 text-xs leading-5 text-muted-foreground">यहां भेजे गए संदेश सिर्फ आप दोनों देख सकते हैं।</p></div><div className="message-bubble message-theirs hindi">आपकी नई रील देखी, रंग बहुत अच्छे हैं।</div><div className="message-bubble message-mine hindi">धन्यवाद! आपकी शूट वाली टिप काम आई।</div></div><div className="message-compose"><input value={message} onChange={(event) => setMessage(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') sendMessage(); }} data-testid="input-message-compose" className="min-w-0 flex-1 rounded-xl bg-muted px-3 py-3 text-sm outline-none" placeholder="संदेश लिखें..." /><IconButton label="मीडिया जोड़ें" testId="button-message-media"><ImagePlus size={18} /></IconButton><button type="button" onClick={sendMessage} data-testid="button-send-message" className="send-button"><Send size={17} /></button></div></div></div></div>;
}

function ProfileView({ profile, posts, admin, onEdit, onToggleAdmin, onLike, onSave, onRemove }: { profile: Profile; posts: Post[]; admin: boolean; onEdit: () => void; onToggleAdmin: () => void; onLike: (id: string) => void; onSave: (id: string) => void; onRemove: (id: string) => void }) {
  const [profileTab, setProfileTab] = useState<'posts' | 'saved'>('posts');
  const visiblePosts = profileTab === 'saved' ? posts.filter((post) => post.saved) : posts.filter((post) => post.user === profile.name || post.localVideo);
  return <div><Topbar title="प्रोफ़ाइल" subtitle="आपकी क्रिएटर दुनिया" onUpload={() => undefined} onNotifications={() => undefined} onSearch={() => undefined} /><div className="mx-auto max-w-[1050px] px-4 pb-12 sm:px-8"><section className="profile-hero rise-in mt-5 rounded-[26px] p-5 sm:p-8"><div className="flex flex-col gap-6 sm:flex-row sm:items-start"><div className="profile-avatar-wrap"><Avatar initials={profile.avatar} size="xl" accent /></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h2 className="hindi text-2xl font-extrabold tracking-[-.05em]">{profile.name}</h2>{admin && <span className="admin-badge"><ShieldCheck size={12} /> एडमिन</span>}</div><div className="mt-1 text-sm text-muted-foreground">{profile.handle} · {profile.location}</div><p className="hindi mt-4 max-w-lg text-sm leading-6 text-foreground/75">{profile.bio}</p><div className="mt-5 flex flex-wrap gap-6"><div><strong className="block text-lg">{formatCount(profile.followers)}</strong><span className="text-[11px] text-muted-foreground">फ़ॉलोअर्स</span></div><div><strong className="block text-lg">{formatCount(profile.following)}</strong><span className="text-[11px] text-muted-foreground">फ़ॉलो कर रहे</span></div><div><strong className="block text-lg">{posts.filter((post) => post.user === profile.name || post.localVideo).length}</strong><span className="text-[11px] text-muted-foreground">पोस्ट</span></div></div></div><button type="button" onClick={onEdit} data-testid="button-edit-profile" className="secondary-button flex items-center gap-2 self-start"><Edit3 size={15} /> प्रोफ़ाइल एडिट करें</button></div></section><div className="mt-7 flex items-center justify-between border-b border-border/70"><div className="flex gap-6"><button type="button" onClick={() => setProfileTab('posts')} data-testid="profile-tab-posts" className={`profile-tab ${profileTab === 'posts' ? 'profile-tab-active' : ''}`}><Film size={16} /> पोस्ट</button><button type="button" onClick={() => setProfileTab('saved')} data-testid="profile-tab-saved" className={`profile-tab ${profileTab === 'saved' ? 'profile-tab-active' : ''}`}><Bookmark size={16} /> सेव किए</button></div><button type="button" onClick={onToggleAdmin} data-testid="button-admin-toggle" className={`admin-toggle ${admin ? 'admin-on' : ''}`}><ShieldCheck size={14} /> {admin ? 'एडमिन ऑन' : 'एडमिन कंट्रोल'}</button></div>{admin && <div className="admin-panel mt-5 flex items-start gap-3 rounded-2xl p-4"><ShieldCheck size={18} className="mt-0.5 shrink-0 text-primary" /><div><div className="text-sm font-bold">मॉडरेशन कंट्रोल सक्रिय</div><p className="hindi mt-1 text-xs leading-5 text-muted-foreground">अब आप इस डिवाइस पर दिख रही पोस्ट को हटा सकते हैं। यह सिर्फ लोकल प्रीव्यू है।</p></div></div>}{visiblePosts.length === 0 ? <div className="mt-6"><EmptyState icon={<Bookmark size={25} />} title={profileTab === 'saved' ? 'अभी कुछ सेव नहीं' : 'आपकी गैलरी खाली है'} description={profileTab === 'saved' ? 'पसंद आई रील पर बुकमार्क दबाएं।' : 'अपना पहला वीडियो साझा करके शुरुआत करें।'} /></div> : <div className="profile-grid mt-6">{visiblePosts.map((post) => <div key={post.id} className="profile-tile group relative overflow-hidden rounded-2xl"><div className="h-full w-full">{post.localVideo ? <video src={post.localVideo} className="h-full w-full object-cover" muted /> : <ReelArtwork post={post} />}</div><div className="absolute inset-0 flex items-end bg-gradient-to-t from-black/65 to-transparent p-3 opacity-0 transition group-hover:opacity-100"><div className="flex items-center gap-3 text-xs font-bold text-white"><span className="flex items-center gap-1"><Heart size={13} fill="currentColor" /> {formatCount(post.likes)}</span><button type="button" onClick={() => onLike(post.id)} data-testid={`profile-like-${post.id}`}><Heart size={14} /></button><button type="button" onClick={() => onSave(post.id)} data-testid={`profile-save-${post.id}`}><Bookmark size={14} /></button>{admin && <button type="button" onClick={() => onRemove(post.id)} data-testid={`profile-remove-${post.id}`}><Trash2 size={14} /></button>}</div></div></div>)}</div>}</div></div>;
}

function UploadModal({ onClose, onPublish }: { onClose: () => void; onPublish: (caption: string, video: string | undefined) => void }) {
  const [caption, setCaption] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  useEffect(() => () => { if (preview.startsWith('blob:')) URL.revokeObjectURL(preview); }, [preview]);
  const pickFile = (event: ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  };
  const publish = () => {
    if (!caption.trim() && !file) return;
    if (file) {
      const reader = new FileReader();
      reader.onload = () => onPublish(caption.trim() || 'मेरी नई कहानी।', String(reader.result));
      reader.readAsDataURL(file);
    } else onPublish(caption.trim(), undefined);
  };
  return <Modal title="अपना फ्रेम साझा करें" eyebrow="नई पोस्ट" onClose={onClose}><div className="mt-6"><button type="button" onClick={() => fileInput.current?.click()} data-testid="button-upload-video" className={`upload-dropzone ${preview ? 'upload-has-preview' : ''}`}>{preview ? <video src={preview} className="h-44 w-full rounded-2xl object-cover" muted autoPlay loop /> : <><div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground"><Video size={24} /></div><div className="text-sm font-bold">वीडियो चुनें</div><div className="mt-1 text-xs text-muted-foreground">MP4, WebM या MOV · 60 सेकंड तक</div></>}<input ref={fileInput} type="file" accept="video/*" onChange={pickFile} data-testid="input-video-file" className="hidden" /></button><label className="mt-5 block"><span className="hindi mb-2 block text-sm font-bold">कैप्शन</span><textarea value={caption} onChange={(event) => setCaption(event.target.value)} data-testid="input-post-caption" rows={3} maxLength={180} className="hindi w-full resize-none rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-primary" placeholder="इस पल के बारे में कुछ लिखें..." /></label><div className="mt-2 text-right font-mono-ui text-[9px] text-muted-foreground">{caption.length}/180</div><button type="button" onClick={publish} disabled={!caption.trim() && !file} data-testid="button-publish-post" className="primary-button mt-5 w-full justify-center disabled:cursor-not-allowed disabled:opacity-40"><Upload size={16} /> पोस्ट प्रकाशित करें</button></div></Modal>;
}

function ProfileEditModal({ profile, onClose, onSave }: { profile: Profile; onClose: () => void; onSave: (profile: Profile) => void }) {
  const [draft, setDraft] = useState(profile);
  const galleryInput = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);
  const update = (key: keyof Profile, value: string) => setDraft((current) => ({ ...current, [key]: key === 'followers' || key === 'following' ? Number(value) : value }));
  const pickPhoto = (event: ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0];
    if (!selected) return;
    const reader = new FileReader();
    reader.onload = () => setDraft((current) => ({ ...current, avatar: String(reader.result) }));
    reader.readAsDataURL(selected);
    event.target.value = '';
  };
  return <Modal title="प्रोफ़ाइल सजाएं" eyebrow="आपकी पहचान" onClose={onClose}><div className="mt-6 space-y-4"><div className="photo-editor-card"><Avatar initials={draft.avatar} size="xl" accent /><div className="min-w-0 flex-1"><div className="hindi text-sm font-bold">प्रोफ़ाइल फोटो</div><p className="hindi mt-1 text-xs leading-5 text-muted-foreground">गैलरी से फोटो चुनें या कैमरा से नई फोटो लें।</p><div className="mt-3 flex flex-wrap gap-2"><button type="button" onClick={() => galleryInput.current?.click()} data-testid="button-profile-gallery" className="photo-choice"><ImagePlus size={15} /> गैलरी</button><button type="button" onClick={() => cameraInput.current?.click()} data-testid="button-profile-camera" className="photo-choice"><Camera size={15} /> कैमरा</button></div></div><input ref={galleryInput} type="file" accept="image/*" onChange={pickPhoto} data-testid="input-profile-gallery" className="hidden" /><input ref={cameraInput} type="file" accept="image/*" capture="user" onChange={pickPhoto} data-testid="input-profile-camera" className="hidden" /></div><label className="block"><span className="hindi mb-2 block text-sm font-bold">नाम</span><input value={draft.name} onChange={(event) => update('name', event.target.value)} data-testid="input-profile-name" className="form-input" /></label><label className="block"><span className="hindi mb-2 block text-sm font-bold">यूज़रनेम</span><input value={draft.handle} onChange={(event) => update('handle', event.target.value)} data-testid="input-profile-handle" className="form-input" /></label><label className="block"><span className="hindi mb-2 block text-sm font-bold">आपके बारे में</span><textarea value={draft.bio} onChange={(event) => update('bio', event.target.value)} data-testid="input-profile-bio" rows={3} className="form-input hindi resize-none" /></label><label className="block"><span className="hindi mb-2 block text-sm font-bold">शहर</span><input value={draft.location} onChange={(event) => update('location', event.target.value)} data-testid="input-profile-location" className="form-input" /></label><button type="button" onClick={() => onSave(draft)} data-testid="button-save-profile" className="primary-button mt-2 w-full justify-center"><Check size={16} /> बदलाव सेव करें</button></div></Modal>;
}

function EmptyState({ icon, title, description, action, onAction }: { icon: ReactNode; title: string; description: string; action?: string; onAction?: () => void }) {
  return <div className="empty-state rounded-[22px] border border-dashed border-border p-8 text-center"><div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground">{icon}</div><h3 className="hindi text-lg font-extrabold">{title}</h3><p className="hindi mx-auto mt-2 max-w-xs text-sm leading-6 text-muted-foreground">{description}</p>{action && onAction && <button type="button" onClick={onAction} data-testid="button-empty-action" className="secondary-button mt-5">{action}</button>}</div>;
}

function SocialApp() {
  const [view, setView] = useState<View>('home');
  const [posts, setPosts] = useState<Post[]>(() => readStorage<Post[]>('infinity-posts', initialPosts));
  const [profile, setProfile] = useState<Profile>(() => readStorage<Profile>('infinity-profile', initialProfile));
  const [followingHandles, setFollowingHandles] = useState<string[]>(() => readStorage<string[]>('infinity-following', []));
  const [admin, setAdmin] = useState(() => readStorage<boolean>('infinity-admin', false));
  const [quality, setQuality] = useState<Quality>(() => readStorage<Quality>('infinity-quality', 'बेहतर'));
  const [showSplash, setShowSplash] = useState(true);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [toast, setToast] = useState('');
  useEffect(() => {
    const timer = window.setTimeout(() => setShowSplash(false), 1100);
    return () => window.clearTimeout(timer);
  }, []);
  useEffect(() => { writeStorage('infinity-posts', posts); }, [posts]);
  useEffect(() => { writeStorage('infinity-profile', profile); }, [profile]);
  useEffect(() => { writeStorage('infinity-following', followingHandles); }, [followingHandles]);
  useEffect(() => { writeStorage('infinity-admin', admin); }, [admin]);
  useEffect(() => { writeStorage('infinity-quality', quality); }, [quality]);
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2400); };
  const togglePost = (id: string, property: 'liked' | 'saved') => setPosts((current) => current.map((post) => post.id === id ? { ...post, [property]: !post[property], likes: property === 'liked' ? post.likes + (post.liked ? -1 : 1) : post.likes, saves: property === 'saved' ? post.saves + (post.saved ? -1 : 1) : post.saves } : post));
  const removePost = (id: string) => { setPosts((current) => current.filter((post) => post.id !== id)); notify('पोस्ट हटा दी गई'); };
  const toggleFollow = (post: Post) => {
    const wasFollowing = followingHandles.includes(post.handle);
    setFollowingHandles((current) => wasFollowing ? current.filter((handle) => handle !== post.handle) : [...current, post.handle]);
    setProfile((current) => ({ ...current, following: Math.max(0, current.following + (wasFollowing ? -1 : 1)) }));
    notify(wasFollowing ? `${post.user} को अनफ़ॉलो किया` : `${post.user} अब आपके फ़ॉलो में हैं`);
  };
  const publish = (caption: string, video: string | undefined) => { const post: Post = { id: `local-${Date.now()}`, user: profile.name, handle: profile.handle, avatar: profile.avatar, caption, likes: 0, comments: 0, saves: 0, visual: 'reel-gradient-4', tone: 'मेरी कहानी', duration: '0:20', localVideo: video }; setPosts((current) => [post, ...current]); setUploadOpen(false); setView('home'); notify('आपकी पोस्ट लाइव है'); };
  const share = async (post: Post) => { try { if (navigator.share) await navigator.share({ title: post.tone, text: post.caption }); else await navigator.clipboard?.writeText(post.caption); notify('लिंक कॉपी हो गया'); } catch { notify('शेयर रद्द किया गया'); } };
  const title = { home: 'होम', reels: 'रील्स', discover: 'खोजें', messages: 'संदेश', profile: 'प्रोफ़ाइल' }[view];
  return <>
    {showSplash && <div id="splash-screen" className="splash-screen" role="status" aria-label="Infinity लोड हो रहा है">
      <div className="logo-container">
        <div className="app-logo" aria-hidden="true">∞</div>
      </div>
      <div className="brand-footer">
        <span className="from-text">from</span>
        <h2 className="brand-name">Infinity</h2>
      </div>
    </div>}
     <div className="app-shell noise"><Sidebar view={view} profile={profile} onNavigate={setView} onUpload={() => setUploadOpen(true)} onHelp={() => notify('सुझाव भेजने के लिए संदेश खोलें')} /><div className="main-shell md:ml-[238px]"><div className="mobile-brand flex items-center justify-between border-b border-border/70 px-4 py-3 md:hidden"><Logo compact /></div>{view === 'home' && <HomeView posts={posts} profile={profile} followingHandles={followingHandles} admin={admin} onLike={(id) => togglePost(id, 'liked')} onSave={(id) => togglePost(id, 'saved')} onShare={share} onRemove={removePost} onFollow={toggleFollow} onUpload={() => setUploadOpen(true)} onNavigate={setView} />}{view === 'reels' && <ReelsView posts={posts} profile={profile} followingHandles={followingHandles} quality={quality} setQuality={setQuality} onLike={(id) => togglePost(id, 'liked')} onSave={(id) => togglePost(id, 'saved')} onShare={share} onFollow={toggleFollow} onUpload={() => setUploadOpen(true)} />}{view === 'discover' && <DiscoverView posts={posts} onOpenReel={() => setView('reels')} />}{view === 'messages' && <MessagesView />}{view === 'profile' && <ProfileView profile={profile} posts={posts} admin={admin} onEdit={() => setEditOpen(true)} onToggleAdmin={() => { setAdmin((current) => !current); notify(!admin ? 'एडमिन कंट्रोल ऑन' : 'एडमिन कंट्रोल ऑफ'); }} onLike={(id) => togglePost(id, 'liked')} onSave={(id) => togglePost(id, 'saved')} onRemove={removePost} />}</div>{uploadOpen && <UploadModal onClose={() => setUploadOpen(false)} onPublish={publish} />}{editOpen && <ProfileEditModal profile={profile} onClose={() => setEditOpen(false)} onSave={(draft) => { setProfile(draft); setEditOpen(false); notify('प्रोफ़ाइल अपडेट हो गई'); }} />}{toast && <div className="toast-pop pop-in fixed bottom-24 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 rounded-full px-4 py-3 text-xs font-bold shadow-xl md:bottom-7"><Check size={15} /> {toast}</div>}<span className="sr-only" data-testid="current-view">{title}</span></div>
  </>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><SocialApp /></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;